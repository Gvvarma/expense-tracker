import React from 'react';
import { PieChart, DollarSign, TrendingUp } from 'lucide-react';
import { Expense, ExpenseCategory } from '../types/expense';
import { calculateTotalExpenses, groupExpensesByCategory, getTopExpenses, categoryColors } from '../utils/expenseUtils';

interface ExpenseStatsProps {
  expenses: Expense[];
}

export default function ExpenseStats({ expenses }: ExpenseStatsProps) {
  const totalExpenses = calculateTotalExpenses(expenses);
  const categoryTotals = groupExpensesByCategory(expenses);
  const topExpenses = getTopExpenses(expenses, 3);

  const categories: ExpenseCategory[] = Array.from(categoryTotals.entries()).map(([name, total]) => ({
    name,
    total,
    color: categoryColors[name]
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <DollarSign className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Total Expenses</h3>
            <p className="text-2xl font-bold text-blue-600">
              ${totalExpenses.toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 bg-green-100 rounded-full">
            <PieChart className="w-6 h-6 text-green-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900">By Category</h3>
        </div>
        <div className="space-y-3">
          {categories.map((category) => (
            <div key={category.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: category.color }}
                />
                <span className="text-sm text-gray-600">{category.name}</span>
              </div>
              <span className="text-sm font-medium">
                ${category.total.toFixed(2)}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 bg-purple-100 rounded-full">
            <TrendingUp className="w-6 h-6 text-purple-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900">Top Expenses</h3>
        </div>
        <div className="space-y-3">
          {topExpenses.map((expense) => (
            <div key={expense.id} className="flex items-center justify-between">
              <span className="text-sm text-gray-600">{expense.description}</span>
              <span className="text-sm font-medium">
                ${expense.amount.toFixed(2)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}