import { Expense, ExpenseCategory } from '../types/expense';

// Time Complexity: O(n) where n is the number of expenses
export const calculateTotalExpenses = (expenses: Expense[]): number => {
  return expenses.reduce((total, expense) => total + expense.amount, 0);
};

// Time Complexity: O(n) where n is the number of expenses
export const groupExpensesByCategory = (expenses: Expense[]): Map<string, number> => {
  const categoryMap = new Map<string, number>();
  
  expenses.forEach(expense => {
    const currentAmount = categoryMap.get(expense.category) || 0;
    categoryMap.set(expense.category, currentAmount + expense.amount);
  });
  
  return categoryMap;
};

// Time Complexity: O(n log n) due to sorting
export const getTopExpenses = (expenses: Expense[], limit: number): Expense[] => {
  return [...expenses]
    .sort((a, b) => b.amount - a.amount)
    .slice(0, limit);
};

// Time Complexity: O(1)
export const generateUniqueId = (): string => {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
};

export const categoryColors: Record<string, string> = {
  Food: '#FF6B6B',
  Transportation: '#4ECDC4',
  Entertainment: '#45B7D1',
  Shopping: '#96CEB4',
  Bills: '#FFEEAD',
  Other: '#D4A5A5'
};